package com.vidhu.microproj.service;

import java.util.List;

import com.vidhu.microproj.model.Venue1;

public interface Venue1Service {
	
	public void addVenue(Venue1 venue);
	public List<Venue1> findAllVenue();
	
}
